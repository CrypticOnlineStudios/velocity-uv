self.__uv$config = {
    prefix: '/prox/',
    bare: '/bare/',
    encodeUrl: Ultraviolet.codec.plain.encode,
    decodeUrl: Ultraviolet.codec.plain.decode,
    handler: '/src/js/uv/uv.handler.js',
    bundle: '/src/js/uv/uv.bundle.js',
    config: '/src/js/uv/uv.config.js',
    sw: '/src/js/uv/uv.sw.js',
};